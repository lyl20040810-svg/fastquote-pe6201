# FastQuote

FastQuote is a local quotation assistant for fastener sales. The customer only needs to provide a model and length plus a quantity in pieces, boxes, or cartons. The application maps that request to its internal DIN933 A2 catalog, applies deterministic pricing rules, checks the internal gross-margin approval gate, and prepares a reviewable customer reply. Approval cases receive a controlled notice that manager approval is still required and not guaranteed, without exposing the margin calculation or 10% threshold.

## Quick start

1. Install Python 3.10 or later. No third-party packages are required for the app.
2. Copy `.env.example` to `.env`.
3. Add `OPENROUTER_API_KEY` and `OPENROUTER_MODEL` to `.env` when OpenRouter mode is required. Do not commit `.env`.
4. Run:

   ```powershell
   python run_app.py
   ```

5. Open `http://127.0.0.1:8765`.

For Google Colab, upload `FastQuote_Colab.ipynb`, open the left sidebar **Secrets** panel, add a secret named `OPENROUTER_API_KEY`, and enable notebook access. Then choose **Runtime > Run all** and use the FastQuote page embedded in the final cell. The notebook reads the key through `google.colab.userdata`; it does not ask for the key in a text box. The embedded page is available only in your Colab session while its runtime is connected. It is not a public link for other people.

The app automatically uses rule fallback mode when the API key or model is missing. The quotation calculation is identical in both modes.

## Example requests

- `Please quote M16x50, 2 cartons.`
- `Please quote M20x80, 5 cartons.`
- `Need M16 bolt, 3 boxes.` (expected to request clarification because length is missing)

## Business rules

- Source price is the price per 1,000 pieces.
- Cost rate: list price x 0.4.
- Base selling rate: list price x 0.5.
- Discount: at least 1 carton 5%, at least 5 cartons 10%, at least 10 cartons 15%.
- Add CNY 5 to total cost only when the order is smaller than one full box. Exactly one box has no surcharge.
- Gross margin: `(revenue - total cost) / revenue x 100%`.
- Gross margin below 10% requires manager approval.
- The system never sends a quotation automatically.

## Tests

Run deterministic unit tests:

```powershell
python -m unittest discover -s tests -v
```

Run the development evaluation set:

```powershell
python run_eval.py --inputs data/dev_eval_inputs.jsonl --answers data/dev_eval_answers.jsonl --mode rules
```

For the final blind evaluation, keep the answer file outside the project until the code is frozen. Then run:

```powershell
python run_eval.py --inputs path\to\final_eval_inputs.jsonl --answers path\to\final_eval_answers.jsonl --mode openrouter --summary-only
```

The first blind result should be retained before any fixes.

## Data status

`data/price_list.json` contains a verified subset transcribed from the two supplied DIN933 A2 price-list photographs. Add the remaining pages before calling the dataset complete. Every row keeps its source page and verification status.

## Project structure

- `fastquote/`: extraction, price lookup, quotation rules, OpenRouter client, and evaluation.
- `static/`: browser interface.
- `data/`: price data, development cases, and blind-evaluation templates.
- `tests/`: boundary and workflow tests.
- `run_app.py`: local web server.
- `run_eval.py`: evaluation runner.

## Security and privacy

- `.env` is ignored by Git.
- Do not publish the real price list without company permission.
- Use anonymized or synthetic prices in any public repository.
- A salesperson must review every result. A manager must approve quotations below the 10% margin threshold.

